
package net.mcreator.magmacubetitan.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CreeperModel;

import net.mcreator.magmacubetitan.entity.UndeadEntity;

public class UndeadRenderer extends MobRenderer<UndeadEntity, CreeperModel<UndeadEntity>> {
	public UndeadRenderer(EntityRendererProvider.Context context) {
		super(context, new CreeperModel(context.bakeLayer(ModelLayers.CREEPER)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(UndeadEntity entity) {
		return new ResourceLocation("magma_cube_titan:textures/entities/lt.png");
	}
}
