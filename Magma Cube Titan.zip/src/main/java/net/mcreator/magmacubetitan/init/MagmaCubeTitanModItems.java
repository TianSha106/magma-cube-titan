
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magmacubetitan.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.magmacubetitan.item.LavaSlimeballItem;
import net.mcreator.magmacubetitan.MagmaCubeTitanMod;

public class MagmaCubeTitanModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MagmaCubeTitanMod.MODID);
	public static final RegistryObject<Item> LAVA_TITAN_SPAWN_EGG = REGISTRY.register("lava_titan_spawn_egg", () -> new ForgeSpawnEggItem(MagmaCubeTitanModEntities.LAVA_TITAN, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> LAVA_SLIMEBALL = REGISTRY.register("lava_slimeball", () -> new LavaSlimeballItem());
	public static final RegistryObject<Item> UNDEAD_SPAWN_EGG = REGISTRY.register("undead_spawn_egg", () -> new ForgeSpawnEggItem(MagmaCubeTitanModEntities.UNDEAD, -1, -1, new Item.Properties()));
	// Start of user code block custom items
	// End of user code block custom items
}
