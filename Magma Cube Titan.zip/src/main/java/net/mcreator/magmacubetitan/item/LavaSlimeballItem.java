
package net.mcreator.magmacubetitan.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LavaSlimeballItem extends Item {
	public LavaSlimeballItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.RARE));
	}
}
